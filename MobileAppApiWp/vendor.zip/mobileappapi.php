<?php
//require_once('vendor/autoload.php');
use \Firebase\JWT\JWT;

/**         
 *
 * @wordpress-plugin
 * Plugin Name:       Mobile app API
 * Description:       All functions which is used in mobile app.
 * Version:           1.0
 * Author:            SS
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

add_action( 'rest_api_init', function () {  
  register_rest_route('mobileapi/v1', '/register', array(
    'methods' => 'POST',
    'callback' => 'MobileApiMakeNewAuthor',
  ) );
  
   register_rest_route('mobileapi/v1', '/create_profile', array(
    'methods' => 'POST',
    'callback' => 'MobileApiMakeNewProfile',
  ) );
  
  register_rest_route('mobileapi/v1', '/retrieve_password', array(
    'methods' => 'POST',
    'callback' => 'RetrivePassword',
  ) );
  
});

// Create new user
function MobileApiMakeNewAuthor($request){
    
    $data=array("status"=>"ok","errormsg"=>"",'error_code'=>"");
    $param = $request->get_params();
    $user_name = $param['email'];
    $user_email = $param['email'];
    $type = $param['type'];
    $password = $param['password'];
    
    // JWT_AUTH_SECRET_KEY define in wp-config
    if($param['jw_auth_sec']!=JWT_AUTH_SECRET_KEY){
        $data['status']="error";
    	$data['errormsg']= __('cheating----.');
    	$data['error_code']="token_error";
    	return new WP_REST_Response( $data, 403 );  
    }
    
    if (!is_email($user_email) ) {
        $data['status']="error";
    	$data['errormsg']= __('This is not a Valid Email.');
    	$data['error_code']="invalid_email";
    	return new WP_REST_Response( $data, 403 );
    }
    
    
    $user_id = username_exists( $user_name );
    
    if($passowrd==" "){
        $data['status']="error";
    	$data['errormsg']= __('Please provide password.');;
    		$data['error_code']="password_blank";
    	return new WP_REST_Response( $data, 403 );   
    }
    if (!$user_id and email_exists($user_email) == false ) {
    	//$random_password = wp_generate_password( $length=12, $include_standard_special_chars=false );
    	$user_id = wp_create_user( $user_name, $password, $user_email );
    	$user = new WP_User($user_id);
    	if($type=="vipeel"){
    	   	$user->set_role('author'); 
    	}
    	
    	if($type=="justlooking"){
    	   	$user->set_role('subscriber'); 
    	}
    
    	add_user_meta($user_id, 'first_name', $first_name);
    	add_user_meta($user_id, 'nickname', $first_name);
    	return new WP_REST_Response($data, 200 );
    } else {
    	$data['status']="error";
    	$data['errormsg']= __('Account exists with this email.');
    		$data['error_code']="user_already";
    	return new WP_REST_Response( $data, 403 );
    }
}
// Create a new profile
function MobileApiMakeNewProfile($request){
    global $wpdb;
    $data=array("status"=>"ok","msg"=>"");
    $param = $request->get_params();
    $first_name = $param['first_name'];
    $vipeeltype = $param['vipeeltype'];
    $kitdate_time = $param['kitdate_time'];
    $vipeelprovider = $param['vipeelprovider'];
    $zipcode = $param['zipcode'];
    $token = $param['token'];
  
    if($token){
       $user_id = GetMobileAPIUserByIdToken($token);
    }else{
        $data['status']="error";
    	$data['msg']= __('cheating----.');
    	return new WP_REST_Response( $data, 403 );  
    }
    
    if($user_id){
       $array_insert = 	array( 
        		'user_id' => $user_id, 
        		'vipeeltype' => $vipeeltype,
        		'kitdate_time'=>$kitdate_time,
        		'vipeelprovider'=>$vipeelprovider,
        		'zipcode'=>$zipcode,
        		
        	);
      
        $insert = CreateProfile($array_insert);	
        if($insert){
           $data=array("status"=>"ok","msg"=>"Profile Create Sucessfully.",'is_profile'=>1);
           return new WP_REST_Response($data, 200); 
       
        }
     }else{
        $data=array("status"=>"error","msg"=>"Session expired please login again."); 
        return new WP_REST_Response($data, 403); 
    }
     
  
}

// Get User ID by token
function GetMobileAPIUserByIdToken($token){
    $decoded_array = array();
    $user_id=0;
    if($token){
      $decoded = JWT::decode($token,JWT_AUTH_SECRET_KEY, array('HS256')); 
    
      $decoded_array = (array) $decoded;
       
    }
    if(count($decoded)>0){
       $user_id = $decoded_array['data']->user->id; 
    }
    return $user_id;
}

// check if profile already 
function CheckifProfileAlready($user_id=NULL){
    $row_id = 0;
     global $wpdb;
     if($user_id){
        $row_id = $wpdb->get_var("SELECT `id` FROM `wp_vipeel_profile` WHERE user_id='".$user_id."'" );
     }
     return $row_id;
}
// Create Profile
function CreateProfile($array_insert){
    global $wpdb;
    $insert = $wpdb->insert('wp_vipeel_profile',$array_insert);
    if($insert){
        //echo $id = $insert->insert_id;
        return true;
    }
    return false;
}

// forgot password
function RetrivePassword($request) {
    global $wpdb, $current_site;
    
    $data=array("status"=>"ok","msg"=>"you will be recive login instructions.");
    $param = $request->get_params();
    $user_login = sanitize_text_field($param['user_login']);
   
    if (!is_email($user_login) ) {
        $data=array("status"=>"error","msg"=>"Please provide valid email.");
        return new WP_REST_Response( $data, 403 );
    }

    if ( empty( $user_login) ) {
        $data=array("status"=>"error","msg"=>"User email is empty.");
        return new WP_REST_Response( $data, 403 ); 
        
    } elseif (strpos( $user_login, '@' )) {
        
        $user_data = get_user_by('email', trim( $user_login ) );
        
    } else {
        $login = trim($user_login);
        $user_data = get_user_by('login', $login);
    }

    if (!$user_data){
        $data=array("status"=>"error","msg"=>"User not found using email.");
        return new WP_REST_Response( $data, 403 ); 
    }
    
   

    // redefining user_login ensures we return the right case in the email
     $user_login = $user_data->user_login;
     $user_email = $user_data->user_email;

   $allow = apply_filters('allow_password_reset', true, $user_data->ID);

    if (! $allow ){
         $data=array("status"=>"error","msg"=>"Password reset not allowed.");
         return new WP_REST_Response( $data, 403 );    
    }elseif (is_wp_error($allow) ){
        $data=array("status"=>"error","msg"=>"Something went wrong");
        return new WP_REST_Response( $data, 403 );  
    }
   
    
    //$key = $wpdb->get_var($wpdb->prepare("SELECT user_activation_key FROM $wpdb->users WHERE user_login = %s", $user_login));
   // if ( empty($key) ) {
        // Generate something random for a key...
         $key=get_password_reset_key($user_data);
        
       // do_action('retrieve_password_key', $user_login, $key);
        // Now insert the new md5 key into the db
        //$wpdb->update($wpdb->users, array('user_activation_key' => $key), array('user_login' => $user_login));
  // }
  
    $message = __('Someone requested that the password be reset for the following account:') . "\r\n\r\n";
    $message .= network_home_url( '/' ) . "\r\n\r\n";
    $message .= sprintf(__('Username: %s'), $user_login) . "\r\n\r\n";
    $message .= __('If this was a mistake, just ignore this email and nothing will happen.') . "\r\n\r\n";
    $message .= __('To reset your password, visit the following address:') . "\r\n\r\n";
    $message .= network_site_url("resetpass/?key=$key&login=" . rawurlencode($user_login), 'login') . "\r\n";
  /* <http://vipeel.testplanets.com/resetpass/?key=wDDY0rDxwfaWPOFZrrmf&login=ajaytest%40gmail.com> */
    if ( is_multisite() )
        $blogname = $GLOBALS['current_site']->site_name;
    else
        // The blogname option is escaped with esc_html on the way into the database in sanitize_option
        // we want to reverse this for the plain text arena of emails.
        $blogname = wp_specialchars_decode(get_option('blogname'), ENT_QUOTES);

    $title = sprintf( __('[%s] Password Reset'), $blogname );

    $title = apply_filters('retrieve_password_title', $title);
    $message = apply_filters('retrieve_password_message', $message, $key);

    if ( $message && !wp_mail($user_email, $title, $message) ){
         $data=array("status"=>"error","msg"=>"The e-mail could not be sent..");
         return new WP_REST_Response( $data, 403 ); 
    }
       // wp_die( __('The e-mail could not be sent.') . "<br />\n" . __('Possible reason: your host may have disabled the mail() function...') );

    return new WP_REST_Response($data, 200); 
}

//apply_filters('jwt_auth_token_before_dispatch', $data, $user);
add_filter('jwt_auth_token_before_dispatch','mobileapi_jwt_auth_token_before_dispatch',10,2);
function mobileapi_jwt_auth_token_before_dispatch($data, $user){

            $role='subscriber';
            if (in_array( 'author', (array) $user->roles ) ) {
               $role='author';
            }
           $CheckifProfileAlready = CheckifProfileAlready($user->ID);
           $data['is_profile']=$CheckifProfileAlready;
           $data['role']=$role;
           
           return $data;
}
?>
